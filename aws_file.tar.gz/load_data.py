import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import numpy as np

train_file = open("train_x.csv")
train_data = train_file.readline()
train_data = train_data.split(',')
train_data = [float(data) for data in train_data]
train_data = np.array(train_data)
train_data = train_data.reshape(-1,64)
imgplot = plt.imshow(train_data)
a = 1